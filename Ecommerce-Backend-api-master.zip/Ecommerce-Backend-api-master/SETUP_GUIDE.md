# 🚀 Complete Setup Guide - E-Commerce Backend API

This guide will walk you through setting up and running the E-Commerce Backend API from scratch.

## 📋 Table of Contents
1. [Prerequisites Installation](#prerequisites-installation)
2. [Database Setup](#database-setup)
3. [Project Setup](#project-setup)
4. [Running the Application](#running-the-application)
5. [Testing the API](#testing-the-api)
6. [Troubleshooting](#troubleshooting)

---

## 1. Prerequisites Installation

### Install Java 17
**Windows:**
1. Download Java 17 from [Oracle](https://www.oracle.com/java/technologies/downloads/) or [OpenJDK](https://adoptium.net/)
2. Run the installer
3. Verify installation:
```bash
java -version
```

**macOS (using Homebrew):**
```bash
brew install openjdk@17
```

**Linux (Ubuntu/Debian):**
```bash
sudo apt update
sudo apt install openjdk-17-jdk
```

### Install Maven
**Windows:**
1. Download Maven from [Apache Maven](https://maven.apache.org/download.cgi)
2. Extract to `C:\Program Files\Apache\maven`
3. Add to PATH environment variable

**macOS:**
```bash
brew install maven
```

**Linux:**
```bash
sudo apt install maven
```

Verify installation:
```bash
mvn -version
```

### Install MySQL
**Windows/macOS:**
1. Download MySQL from [MySQL Downloads](https://dev.mysql.com/downloads/mysql/)
2. Run the installer
3. Remember the root password you set during installation

**Linux:**
```bash
sudo apt install mysql-server
sudo systemctl start mysql
sudo mysql_secure_installation
```

### Install Postman (Optional)
Download from [Postman](https://www.postman.com/downloads/)

---

## 2. Database Setup

### Start MySQL Server
**Windows:**
- MySQL should start automatically or use Services app

**macOS:**
```bash
brew services start mysql
```

**Linux:**
```bash
sudo systemctl start mysql
```

### Create Database
1. Open MySQL command line:
```bash
mysql -u root -p
```

2. Enter your MySQL password

3. Create the database:
```sql
CREATE DATABASE ecommerce_db;
```

4. Verify:
```sql
SHOW DATABASES;
```

5. Exit:
```sql
EXIT;
```

---

## 3. Project Setup

### Navigate to Project Directory
```bash
cd ecommerce-backend
```

### Configure Database Connection
Open `src/main/resources/application.properties` and update:

```properties
spring.datasource.url=jdbc:mysql://localhost:3306/ecommerce_db?createDatabaseIfNotExist=true
spring.datasource.username=root
spring.datasource.password=YOUR_MYSQL_PASSWORD
```

Replace `YOUR_MYSQL_PASSWORD` with your actual MySQL root password.

### Build the Project
```bash
mvn clean install
```

This will:
- Download all dependencies
- Compile the code
- Run tests
- Create a JAR file in `target/` directory

**Note:** First build may take 5-10 minutes as Maven downloads dependencies.

---

## 4. Running the Application

### Method 1: Using Maven (Recommended for Development)
```bash
mvn spring-boot:run
```

### Method 2: Using JAR file
```bash
java -jar target/ecommerce-backend-1.0.0.jar
```

### Verify Application is Running
You should see logs similar to:
```
Started EcommerceBackendApplication in 5.234 seconds
Tomcat started on port(s): 8080 (http)
```

The application is now running at `http://localhost:8080`

---

## 5. Testing the API

### Method 1: Using Postman (Recommended)

#### Import Collection
1. Open Postman
2. Click "Import"
3. Select `Postman_Collection.json` from project root
4. Collection will be imported with all endpoints

#### Test Flow

**Step 1: Register a User**
1. Select "Authentication" → "Register User"
2. Click "Send"
3. Copy the `token` from response
4. Go to collection variables and paste token in `token` variable

**Step 2: Create Products (Need Admin Role)**
First, make yourself admin in database:
```sql
mysql -u root -p
USE ecommerce_db;
UPDATE users SET role = 'ADMIN' WHERE email = 'customer@example.com';
EXIT;
```

Then:
1. Select "Products" → "Create Product (Admin)"
2. Modify product details if needed
3. Click "Send"
4. Repeat to create 3-5 products

**Step 3: Test Cart Operations**
1. Select "Cart" → "Add Item to Cart"
2. Update `productId` to an existing product ID
3. Click "Send"
4. Select "Cart" → "Get User Cart" to view cart

**Step 4: Create an Order**
1. Select "Orders" → "Create Order"
2. Click "Send"
3. Select "Orders" → "Get User Orders" to view your order

### Method 2: Using cURL

#### Register User
```bash
curl -X POST http://localhost:8080/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "password": "password123",
    "firstName": "Test",
    "lastName": "User",
    "phone": "1234567890"
  }'
```

#### Login
```bash
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "password": "password123"
  }'
```

Copy the token from response and use it in subsequent requests.

#### Get All Products
```bash
curl -X GET http://localhost:8080/api/products
```

#### Get Cart (with authentication)
```bash
curl -X GET http://localhost:8080/api/cart \
  -H "Authorization: Bearer YOUR_TOKEN_HERE"
```

---

## 6. Troubleshooting

### Issue: Port 8080 already in use
**Solution:**
Change port in `application.properties`:
```properties
server.port=8081
```

### Issue: Unable to connect to MySQL
**Solutions:**
1. Verify MySQL is running:
   ```bash
   # Linux/macOS
   sudo systemctl status mysql
   
   # macOS with Homebrew
   brew services list
   ```

2. Check MySQL credentials:
   ```bash
   mysql -u root -p
   ```

3. Verify database exists:
   ```sql
   SHOW DATABASES;
   ```

### Issue: JWT secret error
**Solution:**
The JWT secret in `application.properties` should be at least 256 bits (32 characters). Current one is fine, but if you change it, use a long random string.

### Issue: Build fails with compilation error
**Solutions:**
1. Ensure Java 17 is being used:
   ```bash
   java -version
   mvn -version
   ```

2. Clean and rebuild:
   ```bash
   mvn clean
   mvn install
   ```

### Issue: Database tables not created
**Solution:**
Check `application.properties`:
```properties
spring.jpa.hibernate.ddl-auto=update
```

This should automatically create tables.

### Issue: 401 Unauthorized error
**Solutions:**
1. Ensure you're logged in and have a valid token
2. Check token hasn't expired (24 hour validity)
3. Ensure token is properly formatted: `Bearer YOUR_TOKEN`

---

## 📊 Database Schema

After running the application, these tables will be created:

- **users** - User accounts
- **products** - Product catalog
- **carts** - Shopping carts
- **cart_items** - Items in carts
- **orders** - Customer orders
- **order_items** - Items in orders

You can view them in MySQL:
```sql
mysql -u root -p
USE ecommerce_db;
SHOW TABLES;
DESCRIBE users;
```

---

## 🎯 Next Steps

1. **Explore the API**: Use Postman to test all endpoints
2. **Create sample data**: Add multiple products and test the cart flow
3. **Test admin operations**: Update order statuses
4. **Extend functionality**: Add new features like reviews, wishlist, etc.

---

## 📝 Common Testing Scenarios

### Scenario 1: Complete Purchase Flow
1. Register user
2. Login
3. Browse products
4. Add 2-3 products to cart
5. Update quantities
6. Create order
7. View order history

### Scenario 2: Admin Product Management
1. Login as admin
2. Create 5 products in different categories
3. Update product prices
4. Delete a product
5. Search products by category

### Scenario 3: Order Management
1. Customer creates order
2. Admin views all orders
3. Admin updates order status to SHIPPED
4. Customer checks order status
5. Customer cancels pending order

---

## 🆘 Getting Help

If you encounter issues not covered here:
1. Check Spring Boot logs in the console
2. Check MySQL error logs
3. Verify all configurations in `application.properties`
4. Ensure all dependencies are downloaded (`mvn dependency:resolve`)

---

## 🎓 Learning Resources

- [Spring Boot Documentation](https://spring.io/projects/spring-boot)
- [Spring Security](https://spring.io/projects/spring-security)
- [JPA/Hibernate](https://spring.io/guides/gs/accessing-data-jpa/)
- [REST API Design](https://restfulapi.net/)

---


