# E-Commerce Backend API System

A comprehensive RESTful API backend for an e-commerce platform built with **Spring Boot**, featuring user authentication, product management, shopping cart, and order processing.

## 🚀 Features

### Core Functionality
- ✅ **User Authentication & Authorization** - JWT-based secure authentication
- ✅ **Product Management** - Complete CRUD operations for products
- ✅ **Shopping Cart** - Add, update, remove items from cart
- ✅ **Order Processing** - Create orders, track status, cancel orders
- ✅ **Role-Based Access Control (RBAC)** - Customer and Admin roles
- ✅ **Database Integration** - MySQL with JPA/Hibernate ORM
- ✅ **Exception Handling** - Global error handling with meaningful messages
- ✅ **Input Validation** - Request validation using Bean Validation

### Technical Stack
- **Backend Framework**: Spring Boot 3.2.0
- **Security**: Spring Security + JWT
- **Database**: MySQL 8.0+
- **ORM**: JPA/Hibernate
- **Build Tool**: Maven
- **Java Version**: 17

## 📋 Prerequisites

Before running this project, ensure you have:
- Java 17 or higher
- Maven 3.6+
- MySQL 8.0+
- Postman (for API testing)

## 🛠️ Installation & Setup

### 1. Clone the Repository
```bash
git clone <repository-url>
cd ecommerce-backend
```

### 2. Configure MySQL Database
Create a MySQL database:
```sql
CREATE DATABASE ecommerce_db;
```

Update `src/main/resources/application.properties`:
```properties
spring.datasource.url=jdbc:mysql://localhost:3306/ecommerce_db
spring.datasource.username=your_mysql_username
spring.datasource.password=your_mysql_password
```

### 3. Build the Project
```bash
mvn clean install
```

### 4. Run the Application
```bash
mvn spring-boot:run
```

The application will start on `http://localhost:8080`

## 📚 API Documentation

### Base URL
```
http://localhost:8080/api
```

---

## 🔐 Authentication Endpoints

### 1. Register User
**POST** `/auth/register`

**Request Body:**
```json
{
  "email": "user@example.com",
  "password": "password123",
  "firstName": "John",
  "lastName": "Doe",
  "phone": "1234567890"
}
```

**Response:**
```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "type": "Bearer",
  "id": 1,
  "email": "user@example.com",
  "firstName": "John",
  "lastName": "Doe",
  "role": "CUSTOMER"
}
```

### 2. Login User
**POST** `/auth/login`

**Request Body:**
```json
{
  "email": "user@example.com",
  "password": "password123"
}
```

**Response:** Same as registration response

---

## 📦 Product Endpoints

### 1. Get All Products
**GET** `/products`

**Response:**
```json
[
  {
    "id": 1,
    "name": "Product Name",
    "description": "Product description",
    "price": 99.99,
    "stockQuantity": 100,
    "category": "Electronics",
    "imageUrl": "https://example.com/image.jpg",
    "createdAt": "2024-01-15T10:30:00",
    "updatedAt": null
  }
]
```

### 2. Get Product by ID
**GET** `/products/{id}`

### 3. Search Products
**GET** `/products/search?keyword=laptop`

### 4. Get Products by Category
**GET** `/products/category/Electronics`

### 5. Create Product (Admin Only)
**POST** `/products`

**Headers:**
```
Authorization: Bearer {token}
```

**Request Body:**
```json
{
  "name": "Laptop",
  "description": "High-performance laptop",
  "price": 999.99,
  "stockQuantity": 50,
  "category": "Electronics",
  "imageUrl": "https://example.com/laptop.jpg"
}
```

### 6. Update Product (Admin Only)
**PUT** `/products/{id}`

**Headers:**
```
Authorization: Bearer {token}
```

**Request Body:** Same as create product

### 7. Delete Product (Admin Only)
**DELETE** `/products/{id}`

**Headers:**
```
Authorization: Bearer {token}
```

---

## 🛒 Cart Endpoints

All cart endpoints require authentication.

### 1. Get User Cart
**GET** `/cart`

**Headers:**
```
Authorization: Bearer {token}
```

**Response:**
```json
{
  "id": 1,
  "user": {...},
  "items": [
    {
      "id": 1,
      "product": {
        "id": 1,
        "name": "Laptop",
        "price": 999.99
      },
      "quantity": 2,
      "subtotal": 1999.98
    }
  ],
  "totalPrice": 1999.98,
  "createdAt": "2024-01-15T10:30:00",
  "updatedAt": "2024-01-15T11:45:00"
}
```

### 2. Add Item to Cart
**POST** `/cart/items`

**Headers:**
```
Authorization: Bearer {token}
```

**Request Body:**
```json
{
  "productId": 1,
  "quantity": 2
}
```

### 3. Update Cart Item Quantity
**PUT** `/cart/items/{cartItemId}`

**Headers:**
```
Authorization: Bearer {token}
```

**Request Body:**
```json
{
  "quantity": 3
}
```

### 4. Remove Item from Cart
**DELETE** `/cart/items/{cartItemId}`

**Headers:**
```
Authorization: Bearer {token}
```

### 5. Clear Cart
**DELETE** `/cart/clear`

**Headers:**
```
Authorization: Bearer {token}
```

---

## 📋 Order Endpoints

### 1. Get User Orders
**GET** `/orders`

**Headers:**
```
Authorization: Bearer {token}
```

**Response:**
```json
[
  {
    "id": 1,
    "user": {...},
    "orderItems": [
      {
        "id": 1,
        "product": {...},
        "quantity": 2,
        "price": 999.99,
        "subtotal": 1999.98
      }
    ],
    "totalAmount": 1999.98,
    "status": "PENDING",
    "shippingAddress": "123 Main St, City, State",
    "createdAt": "2024-01-15T10:30:00"
  }
]
```

### 2. Get Order by ID
**GET** `/orders/{orderId}`

**Headers:**
```
Authorization: Bearer {token}
```

### 3. Create Order
**POST** `/orders`

**Headers:**
```
Authorization: Bearer {token}
```

**Request Body:**
```json
{
  "shippingAddress": "123 Main St, City, State, ZIP"
}
```

### 4. Cancel Order
**DELETE** `/orders/{orderId}`

**Headers:**
```
Authorization: Bearer {token}
```

### 5. Get All Orders (Admin Only)
**GET** `/orders/admin/all`

**Headers:**
```
Authorization: Bearer {token}
```

### 6. Update Order Status (Admin Only)
**PUT** `/orders/admin/{orderId}/status`

**Headers:**
```
Authorization: Bearer {token}
```

**Request Body:**
```json
{
  "status": "SHIPPED"
}
```

**Available Statuses:** `PENDING`, `PROCESSING`, `SHIPPED`, `DELIVERED`, `CANCELLED`

---

## 🔒 Security

### JWT Authentication
All protected endpoints require a JWT token in the Authorization header:
```
Authorization: Bearer {your-jwt-token}
```

### Roles
- **CUSTOMER**: Can manage their cart, create orders, view their orders
- **ADMIN**: Can manage products, view all orders, update order status

---

## 🧪 Testing with Postman

### 1. Register a New User
- Method: POST
- URL: `http://localhost:8080/api/auth/register`
- Body: Raw JSON (see registration example above)
- Save the token from response

### 2. Create an Admin User (Manual in Database)
```sql
UPDATE users SET role = 'ADMIN' WHERE email = 'admin@example.com';
```

### 3. Test Product Endpoints
- Get all products (no auth required)
- Create product (requires admin token)

### 4. Test Cart Flow
1. Login as customer
2. Add products to cart
3. View cart
4. Update quantities
5. Create order
6. View orders

---

## 📁 Project Structure

```
ecommerce-backend/
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   └── com/
│   │   │       └── ayush/
│   │   │           └── ecommerce/
│   │   │               ├── EcommerceBackendApplication.java
│   │   │               ├── config/
│   │   │               │   └── SecurityConfig.java
│   │   │               ├── controller/
│   │   │               │   ├── AuthController.java
│   │   │               │   ├── CartController.java
│   │   │               │   ├── OrderController.java
│   │   │               │   └── ProductController.java
│   │   │               ├── dto/
│   │   │               │   ├── ApiResponse.java
│   │   │               │   ├── AuthResponse.java
│   │   │               │   ├── CartDTO.java 
│   │   │               │   ├── CartItemDTO.java
│   │   │               │   ├── LoginRequest.java
│   │   │               │   ├── ProductDTO.java 
│   │   │               │   └── RegisterRequest.java
│   │   │               ├── exception/
│   │   │               │   ├── GlobalExceptionHandler.java
│   │   │               │   └── ResourceNotFoundException.java
│   │   │               ├── model/
│   │   │               │   ├── Cart.java 
│   │   │               │   ├── CartItem.java 
│   │   │               │   ├── Order.java
│   │   │               │   ├── OrderItem.java 
│   │   │               │   ├── Product.java 
│   │   │               │   └── User.java 
│   │   │               ├── repository/
│   │   │               │   ├── CartItemRepository.java
│   │   │               │   ├── CartRepository.java
│   │   │               │   ├── OrderRepository.java
│   │   │               │   ├── ProductRepository.java
│   │   │               │   └── UserRepository.java
│   │   │               ├── security/
│   │   │               │   ├── CustomUserDetailsService.java
│   │   │               │   ├── JwtAuthenticationFilter.java
│   │   │               │   └── JwtUtil.java
│   │   │               └── service/
│   │   │                   ├── AuthService.java
│   │   │                   ├── CartService.java 
│   │   │                   ├── OrderService.java
│   │   │                   └── ProductService.java
│   │   └── resources/
│   │       └── application.properties
│   └── test/
│       └── java/
│           └── com/
│               └── ayush/
│                   └── ecommerce/
├── .gitignore
├── pom.xml
├── Postman_Collection.json
├── PROJECT_SUMMARY.md
├── README.md
└── SETUP_GUIDE.md
```


---

## 🎯 Key Features Implementation

### 1. JWT Authentication
- Secure token-based authentication
- Token expiration: 24 hours
- Password encryption using BCrypt

### 2. Role-Based Access Control
- Customer role: Standard user operations
- Admin role: Product and order management

### 3. Cart Management
- Automatic cart creation on user registration
- Real-time cart total calculation
- Duplicate product handling (quantity update)

### 4. Order Processing
- Stock validation before order creation
- Automatic stock decrement
- Order status tracking
- Stock restoration on cancellation

### 5. Exception Handling
- Global exception handler
- Meaningful error messages
- Proper HTTP status codes

---

## 🚀 Future Enhancements

- [ ] Payment gateway integration
- [ ] Email notifications
- [ ] Order tracking
- [ ] Product reviews and ratings
- [ ] Wishlist functionality
- [ ] Advanced search and filters
- [ ] Pagination for large datasets
- [ ] File upload for product images
- [ ] Discount and coupon system

---

## 📝 Notes

- Default password encoder: BCrypt
- Database tables auto-created by Hibernate
- Cross-Origin Resource Sharing (CORS) enabled for all origins
- Logging enabled for debugging

---

## 🤝 Contributing
Contributions are open!
---

## 📧 Contact

**Developer**: Ayush Kandpal  
**Email**: kandpalayush4@gmail.com  
**LinkedIn**: [linkedin.com/in/ayushkandpal](https://www.linkedin.com/in/ayushkandpal-70172a29b)

---

## 📄 License

This project is created for educational and portfolio purposes.
